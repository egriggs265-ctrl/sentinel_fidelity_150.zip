# Sentinel Fidelity 150 Toolkit

A small-account survival-first investing toolkit for a ~$150 starting balance.

This is **not financial advice**. It is a paper-trading, planning, logging, and discipline system designed to keep you from over-risking while you learn.

## What it does

- Creates a $150 starter allocation plan
- Builds a simple ETF/core watchlist
- Builds an experimental/paper-trading watchlist
- Scores trades using risk rules
- Blocks dangerous position sizing
- Creates daily/weekly reports
- Keeps one main log
- Runs fully offline with Python standard library

## Quick start

```bash
cd sentinel_fidelity_150
./install.sh
./bin/run_all.sh
```

Then inspect:

```bash
cat reports/plan.txt
cat reports/risk_review.txt
cat reports/paper_trades.csv
cat logs/sentinel_fidelity.log
```

## Recommended account structure for $150

- $100 protected core / broad market learning bucket
- $30 experimental paper-trade bucket
- $20 cash buffer / mistake buffer

The system defaults to paper mode. Do not enable real trading without separate broker API controls and a lot of testing.

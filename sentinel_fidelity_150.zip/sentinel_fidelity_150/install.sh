#!/usr/bin/env sh
set -eu
mkdir -p reports logs
chmod +x bin/*.sh bin/*.py 2>/dev/null || true
echo "[OK] Sentinel Fidelity 150 installed"

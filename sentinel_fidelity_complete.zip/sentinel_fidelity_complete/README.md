# Sentinel Fidelity Complete

Local paper-only micro-account framework for a $150 Fidelity-style account.

## Run
```bash
cd ~/Downloads && unzip -o sentinel_fidelity_complete.zip && cd sentinel_fidelity_complete && chmod +x install.sh bin/*.sh bin/*.py tests/*.sh && ./install.sh && ./bin/run_demo.sh && ./bin/test.sh && cat reports/summary.txt
```

No real orders. Paper mode only.

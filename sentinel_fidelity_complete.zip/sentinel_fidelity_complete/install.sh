#!/usr/bin/env sh
set -eu
mkdir -p reports logs runtime data/snapshots data/imports data/historical
chmod +x bin/*.sh bin/*.py tests/*.sh || true
[ -f reports/trade_journal.csv ] || printf 'timestamp,symbol,side,size,entry,stop,target,status,pnl,reason
' > reports/trade_journal.csv
echo "[OK] Sentinel Fidelity Complete installed"
echo "Run: ./bin/run_all.sh && ./bin/test.sh && cat reports/summary.txt"

# Blueprint

install -> run_all -> engines -> reports -> summary -> tests -> backup/snapshot.

Core rule: protect capital first. BLOCK means do not force the trade.

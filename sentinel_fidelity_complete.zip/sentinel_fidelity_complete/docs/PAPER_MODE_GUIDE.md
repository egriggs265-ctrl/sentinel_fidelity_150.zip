# Paper Mode Guide

Use paper_inputs.csv for ideas. Use add_trade.sh to record decisions. Never treat paper wins as proof until journal history exists.

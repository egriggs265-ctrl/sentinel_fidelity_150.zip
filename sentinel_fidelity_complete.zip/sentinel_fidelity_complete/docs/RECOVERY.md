# Recovery

Run ./bin/backup.sh before edits. Restore with ./bin/restore.sh <backup.tar.gz>.

# Commands

./install.sh
./bin/run_all.sh
./bin/run_demo.sh
./bin/test.sh
./bin/add_trade.sh SYMBOL SIDE SIZE ENTRY STOP TARGET STATUS PNL REASON
./bin/backup.sh
./bin/health_check.sh

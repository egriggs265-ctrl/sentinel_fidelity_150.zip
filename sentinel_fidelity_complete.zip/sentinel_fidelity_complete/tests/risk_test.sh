#!/usr/bin/env sh
set -eu
grep -q "verdict=BLOCK" reports/risk_review.txt
grep -q "verdict=PASS" reports/risk_review.txt
echo "[OK] risk"

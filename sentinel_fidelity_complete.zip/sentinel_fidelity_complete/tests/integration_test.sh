#!/usr/bin/env sh
set -eu
[ -f reports/summary.txt ]
grep -q "Sentinel Fidelity Complete Summary" reports/summary.txt
grep -q "PAPER ONLY" reports/summary.txt
echo "[OK] integration"

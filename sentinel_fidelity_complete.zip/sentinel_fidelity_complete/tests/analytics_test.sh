#!/usr/bin/env sh
set -eu
[ -f reports/analytics_report.txt ]
[ -f reports/drawdown_report.txt ]
echo "[OK] analytics"

#!/usr/bin/env sh
set -eu
[ -f reports/trade_journal.csv ]
grep -q "timestamp,symbol" reports/trade_journal.csv
echo "[OK] journal"

#!/usr/bin/env sh
set -eu
[ -x bin/run_all.sh ]
[ -f config/settings.json ]
[ -f data/paper_inputs.csv ]
echo "[OK] smoke"
